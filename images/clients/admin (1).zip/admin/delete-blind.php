<?php 
require('config.php');
$ID=$_GET['Id'];
$query = "delete from tblblind where Id=".$ID;
$mysqli->query($query);
header('location:blinds.php')
?>
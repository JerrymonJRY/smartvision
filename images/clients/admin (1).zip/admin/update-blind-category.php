<?php
require('config.php');
if(isset($_POST['edit_blind_cat'])){
    $id=$_POST['blind_cat_Id'];
    $name=$_POST['blind_cat_name'];
    $desc=$_POST['blind_cat_desc'];
    $image=$_FILES['blind_cat_image'];
    $oldfile = $_POST['old_blind_cat'];
    $file = $_FILES['blind_cat_image']['name'];
    if($file!=""){
        $img_loc=$_FILES['blind_cat_image']['tmp_name'];
        $img_name=$_FILES['blind_cat_image']['name'];
        $img_des="uploads/".$img_name;
        move_uploaded_file($img_loc,'../uploads/'.$img_name);
    }
    else{
        $img_des=$oldfile;
    }
   
   
    //inserting to db
    $query = "update tblblindcategory set Name='".$name."',Description='".$desc."',Image='".$img_des."' where Id='".$id."'";
    $mysqli->query($query);
    header('location:BlindCategories.php');
}
?>
<?php
require('config.php');
if(isset($_POST['add_blind'])){
    $name=$_POST['blind_name'];
    $category=$_POST['blind_category'];
    $image=$_FILES['blind_image'];
    print_r($_FILES['blind_image']);
    $img_loc=$_FILES['blind_image']['tmp_name'];
    $img_name=$_FILES['blind_image']['name'];
    $img_des="uploads/".$img_name;
    move_uploaded_file($img_loc,'../uploads/'.$img_name);
    

    //inserting to db
    $query = "insert into tblblind( Name, CategoryId, Image) values ('".$name."','".$category."','".$img_des."')";
    $mysqli->query($query);
    header('location:blinds.php');
}
?>
<?php
require('config.php');
if(isset($_POST['edit_curtain_cat'])){
    $id=$_POST['curtain_cat_Id'];
    $name=$_POST['curtain_cat_name'];
    $desc=$_POST['curtain_cat_desc'];
    $image=$_FILES['curtain_cat_image'];
    $oldfile = $_POST['old_curtain_cat'];
    $file = $_FILES['curtain_cat_image']['name'];
    if($file!=""){
        $img_loc=$_FILES['curtain_cat_image']['tmp_name'];
        $img_name=$_FILES['curtain_cat_image']['name'];
        $img_des="uploads/".$img_name;
        move_uploaded_file($img_loc,'../uploads/'.$img_name);
    }
    else{
        $img_des=$oldfile;
    }
   
    //inserting to db
    $query = "update tblcurtaincategory set Name='".$name."',Description='".$desc."',Image='".$img_des."' where Id='".$id."'";
    $mysqli->query($query);
    header('location:CurtainCategories.php');
}
?>
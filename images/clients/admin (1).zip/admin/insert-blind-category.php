<?php
require('config.php');
if(isset($_POST['add_blind_cat'])){
    $name=$_POST['blind_cat_name'];
   $desc=$_POST['blind_cat_desc'];
   $image=$_FILES['blind_cat_image'];
   $img_loc=$_FILES['blind_cat_image']['tmp_name'];
   $img_name=$_FILES['blind_cat_image']['name'];
   $img_des="uploads/".$img_name;
   move_uploaded_file($img_loc,'../uploads/'.$img_name);

    //inserting to db
    $query = "insert into tblblindcategory( Name,Description,Image) values ('".$name."','".$desc."','".$img_des."')";
    $mysqli->query($query);
    header('location:BlindCategories.php');
}
?>
<?php 
session_start();
require('config.php');
 if(isset($_POST['email']) && isset($_POST['password'])){
   
    $username=$_POST['email'];
    $password=$_POST['password'];
    if (empty($username)) {

        header("Location: login.php?error=User Name is required");

        exit();

    }else if(empty($password)){

        header("Location: login.php?error=Password is required");

        exit();

    }else{
        $query = "select * from tblLogin where Username='".$username."' and Password='".$password."'";
        $userdata=$mysqli->query($query);
        if (mysqli_num_rows($userdata) === 1) {
            $row = mysqli_fetch_assoc($userdata);
            if ($row['Username'] === $username && $row['Password'] === $password) {

                echo "Logged in!";

                $_SESSION['username'] = $row['Username'];

                $_SESSION['password'] = $row['Password'];

                $_SESSION['id'] = $row['Id'];

                header("Location: home.php");

                exit();

            }else{

                header("Location: login.php?error=Incorect User name or password");

                exit();

            }
        }
        else{

            header("Location: login.php?error=Incorect User name or password");

            exit();

        }
    }
 }
else{

    header("Location: login.php");

    exit();

}
?>
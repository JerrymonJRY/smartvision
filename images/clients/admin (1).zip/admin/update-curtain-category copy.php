<?php
require('config.php');
if(isset($_POST['edit_curtain_cat'])){
    $id=$_POST['curtain_cat_Id'];
    $name=$_POST['curtain_cat_name'];
    $desc=$_POST['curtain_cat_desc'];
   
    //inserting to db
    $query = "update tblcurtaincategory set Name='".$name."',Description='".$desc."' where Id='".$id."'";
    $mysqli->query($query);
    header('location:CurtainCategories.php');
}
?>
<?php
require('config.php');
if(isset($_POST['edit_user'])){
    $id=$_POST['userId'];
    $name=$_POST['username'];
    $password=$_POST['password'];
    
   
    //inserting to db
    $query = "update tbllogin set Username='".$name."',Password='".$password."' where Id='".$id."'";
    $mysqli->query($query);
    header('location:home.php');
   
}
?>
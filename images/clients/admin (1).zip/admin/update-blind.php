<?php
require('config.php');
if(isset($_POST['edit_blind'])){
    $id=$_POST['blindId'];
    $name=$_POST['blind_name'];
    $category=$_POST['blind_category'];
    $image=$_FILES['blind_image'];
    $oldfile = $_POST['oldblind'];
    $file = $_FILES['blind_image']['name'];
    if($file!=""){
        $img_loc=$_FILES['blind_image']['tmp_name'];
        $img_name=$_FILES['blind_image']['name'];
        $img_des="uploads/".$img_name;
        move_uploaded_file($img_loc,'../uploads/'.$img_name);
    }
    else{
        $img_des=$oldfile;
    }
   
    //inserting to db
    $query = "update tblblind set Name='".$name."',CategoryId='".$category."', Image='".$img_des."' where Id='".$id."'";
    $mysqli->query($query);
    header('location:blinds.php');
   
}
?>
<?php
	$dbHost = "localhost";
	$dbDatabase = "chalabiu_rrc";
	$dbPassword = "";
	$dbUser = "root";
	 $mysqli = new mysqli($dbHost, $dbUser, $dbPassword, $dbDatabase);
    // $con=mysqli_connect($dbHost,$dbUser,$dbPassword,$dbDatabase);
?>
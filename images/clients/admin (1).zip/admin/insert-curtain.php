<?php
require('config.php');
if(isset($_POST['add_curtain'])){
    $name=$_POST['curtain_name'];
    $category=$_POST['curtain_category'];
    $image=$_FILES['curtain_image'];
    $img_loc=$_FILES['curtain_image']['tmp_name'];
    $img_name=$_FILES['curtain_image']['name'];
    $img_des="uploads/".$img_name;
    move_uploaded_file($img_loc,'../uploads/'.$img_name);
    

    //inserting to db
    $query = "insert into tblcurtain( Name, CategoryId, Image) values ('".$name."','".$category."','".$img_des."')";
    $mysqli->query($query);
    header('location:curtains.php');
}
?>
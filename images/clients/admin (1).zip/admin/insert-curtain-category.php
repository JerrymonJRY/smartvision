<?php
require('config.php');
if(isset($_POST['add_curtain_cat'])){
    $name=$_POST['curtain_cat_name'];
   $desc=$_POST['curtain_cat_desc'];
   $image=$_FILES['curtain_cat_image'];
    $img_loc=$_FILES['curtain_cat_image']['tmp_name'];
    $img_name=$_FILES['curtain_cat_image']['name'];
    $img_des="uploads/".$img_name;
    move_uploaded_file($img_loc,'../uploads/'.$img_name);

    //inserting to db
    $query = "insert into tblcurtaincategory( Name,Description, Image) values ('".$name."','".$desc."','".$img_des."')";
    $mysqli->query($query);
    header('location:CurtainCategories.php');
}
?>
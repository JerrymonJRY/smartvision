<?php 
require('config.php');
$ID=$_GET['Id'];
$query = "delete from tblcurtain where Id=".$ID;
$mysqli->query($query);
header('location:curtains.php')
?>